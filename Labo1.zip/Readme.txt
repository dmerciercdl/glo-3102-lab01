1. Lancer index.html dans votre navigateur préféré
2. Apprécier le site
3. Acheter un "Connected Cat"